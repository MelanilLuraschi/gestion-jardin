<?php
$conn = new mysqli('localhost', 'root', '123456', 'gestion-pagos') or die("Could not connect to mysql" . mysqli_error($con));
